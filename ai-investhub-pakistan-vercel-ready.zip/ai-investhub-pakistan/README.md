# AI InvestHub Pakistan

**Smarter Investment Management, Powered by AI**

AI-assisted investment management platform designed for the Pakistani market (MVP with **simulated funds only**).

> **IMPORTANT**: This is a software demonstration. Real-money deposits, investment execution, and payouts are **disabled**. No regulatory license is claimed. All balances and transactions are clearly marked DEMO / simulated.

## Features in this MVP

- Professional public website (Home, Products, How it works, Pricing, Risk disclosure, FAQ, legal pages)
- Secure registration & login (bcrypt password hashing, HTTP-only session cookies, JWT)
- Investor dashboard with available cash, invested principal, holdings, recent activity
- Investment product catalog with DEMO products
- Simulated deposit → ledger credit
- Simulated investment order → double-entry ledger + holding
- Basic admin dashboard (role-gated)
- Prisma schema covering users, verification, products, orders, holdings, deposits, withdrawals, double-entry ledger, notifications, AI conversations, audit logs
- Seed data with demo accounts

## Tech stack

- Next.js 15 (App Router) + TypeScript
- Tailwind CSS (custom navy / emerald palette)
- Prisma ORM (PostgreSQL for persistent local and production deployment)
- bcryptjs + jose for auth
- Zod for validation
- Decimal arithmetic for money (no floating point)

## Quick start (local)

### Prerequisites
- Node.js 18.17+ (recommended 20+)
- npm or pnpm

### 1. Install

```bash
cd ai-investhub-pakistan
# Copy .env.example to .env and set DATABASE_URL to a local PostgreSQL instance
npm install
```

### 2. Database

Configure `DATABASE_URL` for PostgreSQL in `.env`, then run:

```bash
npx prisma generate
npx prisma db push
```

Only seed a disposable non-production database, and only after setting `ALLOW_DESTRUCTIVE_DEMO_SEED=true`.

### 3. Run

```bash
npm run dev
```

Open http://localhost:3000

### Demo accounts

| Role     | Email              | Password       |
|----------|--------------------|----------------|
| Investor | investor@demo.pk   | DemoPass123!   |
| Admin    | Not created by default | Set SEED_DEMO_ADMIN=true only for a disposable private demo   |

The demo investor is seeded with **500,000 PKR** simulated cash. Seeding is destructive and requires explicit opt-in; do not run it against a database with data to preserve.

## Environment

See `.env.example`. Critical flags:

- `ENABLE_REAL_MONEY=false` — must stay false until legal approval
- `AUTH_SECRET` — set a long random value for production

## PostgreSQL and Vercel deployment

The deployment-ready schema is configured for PostgreSQL. See [DEPLOYMENT.md](./DEPLOYMENT.md) for GitHub, Vercel, database, and environment-variable setup.

The demo seed script is destructive and refuses to run unless `ALLOW_DESTRUCTIVE_DEMO_SEED=true` is set against a disposable non-production database. It does not create a demo admin account unless `SEED_DEMO_ADMIN=true` is also set. Never seed a public/production database.

## Project structure (key paths)

```
src/
  app/                 # Pages & API routes
  components/          # UI components
  lib/
    auth/              # Password hashing, sessions
    db/                # Prisma client
    ledger/            # Double-entry engine (simulated)
    utils/
prisma/
  schema.prisma
  seed.ts
```

## Security notes (MVP)

- Passwords are bcrypt-hashed (12 rounds)
- Sessions are HTTP-only cookies + server-side session records
- Server-side authorization on protected routes
- No real payment or KYC provider is connected
- Audit log table is present for future expansion

## Known limitations / next steps

1. Email verification is simulated (always verified on register)
2. No real KYC / AML provider integration
3. No real payment gateway (Raast / bank / PSP)
4. AI assistant UI and provider wiring not yet implemented (schema ready)
5. Background job runner not yet wired
6. Full admin CRUD modules are skeletons
7. Withdrawal UI is minimal
8. No automated test suite executed in this delivery
9. Production readiness gate and regulatory checklist must be completed before enabling live money

## Regulatory readiness (must complete before production)

- [ ] Company structure and SECP licensing review
- [ ] Investment product legality confirmed
- [ ] Banking / payment provider written approvals
- [ ] KYC/AML/sanctions procedures and provider
- [ ] Tax, privacy, recordkeeping obligations
- [ ] Independent security review
- [ ] Formal decision to enable `ENABLE_REAL_MONEY`

Engage qualified Pakistani legal and compliance professionals. Do not invent license numbers or imply approval.

## License

Proprietary — for demonstration and authorized development only.
