# Vercel Deployment Guide — AI InvestHub Pakistan

This project is a **demo-only** investment platform. Keep `ENABLE_REAL_MONEY=false`, `ENABLE_PAYMENT_PROVIDER=false`, and `ENABLE_KYC_PROVIDER=false`. Do not accept real deposits or promise returns. The demo seed script deletes existing records, so **never run `npm run db:seed` against a production database containing data you need**.

## 1. Create a PostgreSQL database

1. Create a managed PostgreSQL database (Neon is one option; Supabase or another PostgreSQL provider can also work).
2. Copy its PostgreSQL connection string. Use the provider's pooled/runtime URL for `DATABASE_URL` if it provides one. If the provider offers a separate direct URL for schema changes, keep it for your local migration/admin workflow.
3. Ensure SSL is enabled in the URL (commonly `?sslmode=require`). Keep credentials private.

The Prisma schema in this deployment package is configured for PostgreSQL. This is a schema/provider change from the original SQLite MVP; it does not migrate any existing local SQLite data.

## 2. Push the project to GitHub (Windows)

1. Install Git for Windows from https://git-scm.com/download/win and create/sign in to an account at https://github.com.
2. Extract `ai-investhub-pakistan-vercel-ready.zip` to a normal folder.
3. Open that folder in File Explorer, click the address bar, type `cmd`, and press Enter.
4. Run these commands, replacing `YOUR_GITHUB_USERNAME` with your GitHub username:

```bat
git init
git add .
git commit -m "Prepare AI InvestHub for Vercel"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/ai-investhub-pakistan.git
git push -u origin main
```

5. If GitHub asks you to authenticate, follow its browser sign-in flow. Do not commit `.env`, database credentials, API keys, or real user data. `.gitignore` excludes `.env` files.

If Git says your identity is unknown, run `git config --global user.name "Your Name"` and `git config --global user.email "YOUR_GITHUB_EMAIL"`, then repeat the commit command.

## 3. Import into Vercel

1. Sign in at https://vercel.com using GitHub.
2. Choose **Add New → Project**, then import `ai-investhub-pakistan`.
3. Keep Framework Preset as **Next.js** and the Root Directory as `./`.
4. Add the Environment Variables below for **Production**, and optionally Preview if you want separate test deployments.
5. Deploy after the database variables are configured.

Required environment variables:

- `DATABASE_URL` = your managed PostgreSQL connection string
- `AUTH_SECRET` = a cryptographically random secret, at least 32 characters
- `NEXT_PUBLIC_APP_URL` = the deployed `https://...vercel.app` URL (update after first deployment if needed)
- `NEXT_PUBLIC_APP_NAME` = `AI InvestHub Pakistan`
- `ENABLE_REAL_MONEY` = `false`
- `ENABLE_KYC_PROVIDER` = `false`
- `ENABLE_PAYMENT_PROVIDER` = `false`
- `ENABLE_AI_PROVIDER` = `false`

Generate a secret in PowerShell with:

```powershell
$b = New-Object byte[] 48
[System.Security.Cryptography.RandomNumberGenerator]::Fill($b)
[Convert]::ToBase64String($b)
```

Copy the output into Vercel as `AUTH_SECRET`; do not put it in GitHub or send it in chat.

## 4. Initialize the database schema

After setting `DATABASE_URL`, run schema setup from your own computer with Node.js installed. In the extracted project folder, create a local `.env` file (never commit it) containing the production PostgreSQL `DATABASE_URL` and a random `AUTH_SECRET`, then run:

```bat
npm install
npx prisma generate
npx prisma db push
```

For the safest setup, use a staging database first and review Prisma's planned schema changes before applying them to any database with existing data. This app has no production migration history yet; `db push` creates/aligns tables but does not migrate your old SQLite data. For future schema changes, adopt and test Prisma migration files and deploy them through a controlled migration workflow.

Then redeploy in Vercel if the first build happened before the schema was ready. Remove your local `.env` when finished or keep it private and excluded from Git.

## 5. Demo data (optional)

For a fresh, disposable non-production demo database only, run `npm run db:seed` with `ALLOW_DESTRUCTIVE_DEMO_SEED=true` and `DATABASE_URL` pointing at that database. The script clears existing tables before seeding and refuses to run in `NODE_ENV=production`; never run it against a database with records you want to preserve. It creates the demo investor and simulated balance. A demo admin account is not created unless `SEED_DEMO_ADMIN=true` is also set; do not enable this for a public deployment.

## 6. Verify deployment

- Open the Vercel deployment URL and check the home page, products, registration, and login.
- Register a new test user and verify that login/session works.
- Test demo deposit and demo investment only using a disposable test account/database.
- Check Vercel → Project → Logs if the site returns a 500 error. A Prisma connection/schema error usually means `DATABASE_URL` is wrong or the schema has not been pushed.
- Keep real-money and payment-provider flags disabled. A deployment is not a regulatory approval or security audit.

## Important limitations

This is a deployment-prepared MVP, not a fully audited financial product. Email verification, KYC/AML, production-grade monitoring, automated tests, and real payment integrations are not complete. Before any real-money use, obtain qualified Pakistan legal/compliance advice and required licensing, banking and provider approvals, plus an independent security review.
