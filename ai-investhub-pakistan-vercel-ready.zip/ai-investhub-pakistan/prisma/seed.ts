import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/auth/password";

const prisma = new PrismaClient();

async function main() {
  if (process.env.NODE_ENV === "production" || process.env.ALLOW_DESTRUCTIVE_DEMO_SEED !== "true") {
    throw new Error("Demo seeding is destructive. Use a disposable non-production database and explicitly set ALLOW_DESTRUCTIVE_DEMO_SEED=true.");
  }
  console.log("Seeding AI InvestHub Pakistan DEMO data into a disposable database...");

  // Clean existing (safe for local MVP)
  await prisma.ledgerEntry.deleteMany();
  await prisma.ledgerTransaction.deleteMany();
  await prisma.ledgerAccount.deleteMany();
  await prisma.investmentHolding.deleteMany();
  await prisma.investmentOrder.deleteMany();
  await prisma.depositRequest.deleteMany();
  await prisma.withdrawalRequest.deleteMany();
  await prisma.productDocument.deleteMany();
  await prisma.valuationRecord.deleteMany();
  await prisma.investmentProduct.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.verificationRecord.deleteMany();
  await prisma.investorEligibility.deleteMany();
  await prisma.userProfile.deleteMany();
  await prisma.session.deleteMany();
  await prisma.loginHistory.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.user.deleteMany();
  await prisma.systemSetting.deleteMany();

  const demoPassword = await hashPassword("DemoPass123!");

  // Demo Investor
  const investor = await prisma.user.create({
    data: {
      email: "investor@demo.pk",
      passwordHash: demoPassword,
      emailVerified: true,
      emailVerifiedAt: new Date(),
      role: "INVESTOR",
      status: "ACTIVE",
      profile: {
        create: {
          fullLegalName: "Demo Investor",
          phone: "+92-300-0000000",
          country: "PK",
          city: "Karachi",
        },
      },
      verification: {
        create: {
          status: "VERIFIED",
          provider: "manual",
          notes: "DEMO verification - not real KYC",
        },
      },
      eligibility: {
        create: {
          isEligible: true,
          riskScore: 3,
          acceptedTermsAt: new Date(),
          acceptedRiskAt: new Date(),
        },
      },
    },
  });

  // Publicly documented demo credentials must not create a public admin by default.
  if (process.env.SEED_DEMO_ADMIN === "true") {
    await prisma.user.create({
      data: {
        email: "admin@demo.pk",
        passwordHash: demoPassword,
        emailVerified: true,
        emailVerifiedAt: new Date(),
        role: "SUPER_ADMIN",
        status: "ACTIVE",
        profile: {
          create: {
            fullLegalName: "Demo Administrator",
            country: "PK",
          },
        },
      },
    });
  }

  // Demo Products
  const product1 = await prisma.investmentProduct.create({
    data: {
      name: "DEMO Equity Growth Fund",
      slug: "demo-equity-growth",
      description:
        "This is a DEMO product for illustration only. It does not represent a real investment opportunity. All values are simulated.",
      shortDescription: "Simulated diversified equity exposure (DEMO only)",
      issuer: "Demo Authorized Manager (Simulated)",
      category: "FUND",
      underlyingAssets: "Simulated Pakistani listed equities basket",
      minInvestment: 10000,
      maxInvestment: 5000000,
      currency: "PKR",
      durationMonths: 12,
      liquidity: "Monthly redemption window (DEMO)",
      riskClass: "MEDIUM",
      feeSchedule: JSON.stringify({ managementFee: "1.5% p.a. (DEMO)", entryFee: "0%" }),
      valuationMethod: "Daily NAV (simulated)",
      distributionPolicy: "Reinvested (DEMO)",
      redemptionPolicy: "Subject to product terms (DEMO)",
      eligibilityCriteria: "Verified Pakistani residents (DEMO)",
      status: "ACTIVE",
      isDemo: true,
    },
  });

  const product2 = await prisma.investmentProduct.create({
    data: {
      name: "DEMO Fixed Income Note",
      slug: "demo-fixed-income",
      description:
        "Simulated fixed-income style product for MVP testing only. No real returns are generated or guaranteed.",
      shortDescription: "Simulated income product (DEMO only)",
      issuer: "Demo Authorized Issuer (Simulated)",
      category: "OTHER",
      minInvestment: 50000,
      maxInvestment: 10000000,
      currency: "PKR",
      durationMonths: 6,
      liquidity: "At maturity (DEMO)",
      riskClass: "LOW",
      feeSchedule: JSON.stringify({ managementFee: "0.75% p.a. (DEMO)" }),
      status: "ACTIVE",
      isDemo: true,
    },
  });

  await prisma.valuationRecord.createMany({
    data: [
      {
        productId: product1.id,
        valuePerUnit: 1.0,
        asOfDate: new Date(),
        source: "DEMO",
      },
      {
        productId: product2.id,
        valuePerUnit: 1.0,
        asOfDate: new Date(),
        source: "DEMO",
      },
    ],
  });

  // Give demo investor some simulated cash via ledger
  const { postDeposit } = await import("../src/lib/ledger/engine");
  await postDeposit(investor.id, 500000, "SEED-DEMO-DEPOSIT");

  await prisma.systemSetting.createMany({
    data: [
      { key: "platform_mode", value: "DEMO", description: "DEMO | STAGING | PRODUCTION" },
      { key: "real_money_enabled", value: "false", description: "Must remain false until legal approval" },
      { key: "maintenance_mode", value: "false" },
    ],
  });

  console.log("Seed complete.");
  console.log("Demo Investor: investor@demo.pk / DemoPass123!");
  if (process.env.SEED_DEMO_ADMIN === "true") console.log("Demo Admin:    admin@demo.pk / DemoPass123! (change immediately; demo only)");
  console.log("All data is clearly marked DEMO / simulated.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
