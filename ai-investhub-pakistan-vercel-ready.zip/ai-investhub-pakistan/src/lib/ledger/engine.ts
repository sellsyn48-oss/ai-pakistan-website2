import { prisma } from "@/lib/db/prisma";
import { Decimal } from "@prisma/client/runtime/library";

/**
 * Double-entry ledger engine (simulated).
 * All amounts use Decimal. Never use floating point for money.
 */

async function getOrCreateAccount(code: string, name: string, type: string, userId?: string) {
  let account = await prisma.ledgerAccount.findUnique({ where: { code } });
  if (!account) {
    account = await prisma.ledgerAccount.create({
      data: { code, name, type, userId, currency: "PKR" },
    });
  }
  return account;
}

export async function postDeposit(userId: string, amount: number, reference?: string) {
  const amt = new Decimal(amount);
  if (amt.lte(0)) throw new Error("Amount must be positive");

  const cashAccount = await getOrCreateAccount(
    `CASH_USER_${userId}`,
    "User Available Cash",
    "ASSET",
    userId
  );
  const liabilityAccount = await getOrCreateAccount(
    "SYSTEM_DEPOSITS",
    "System Deposit Liability",
    "LIABILITY"
  );

  return prisma.$transaction(async (tx) => {
    const txn = await tx.ledgerTransaction.create({
      data: {
        type: "DEPOSIT",
        reference,
        description: `Simulated deposit of ${amount} PKR`,
        isSimulated: true,
        status: "POSTED",
      },
    });

    await tx.ledgerEntry.createMany({
      data: [
        { transactionId: txn.id, accountId: cashAccount.id, debit: amt, credit: new Decimal(0) },
        { transactionId: txn.id, accountId: liabilityAccount.id, debit: new Decimal(0), credit: amt },
      ],
    });

    return txn;
  });
}

export async function postInvestment(
  userId: string,
  amount: number,
  orderId: string
) {
  const amt = new Decimal(amount);
  const cashAccount = await getOrCreateAccount(
    `CASH_USER_${userId}`,
    "User Available Cash",
    "ASSET",
    userId
  );
  const principalAccount = await getOrCreateAccount(
    `PRINCIPAL_USER_${userId}`,
    "User Invested Principal",
    "ASSET",
    userId
  );

  // Check available cash (simplified - sum of debits - credits)
  const entries = await prisma.ledgerEntry.findMany({
    where: { accountId: cashAccount.id },
  });
  let balance = new Decimal(0);
  for (const e of entries) {
    balance = balance.add(e.debit).sub(e.credit);
  }
  if (balance.lt(amt)) {
    throw new Error("Insufficient available cash");
  }

  return prisma.$transaction(async (tx) => {
    const txn = await tx.ledgerTransaction.create({
      data: {
        type: "INVESTMENT",
        reference: orderId,
        description: `Simulated investment subscription ${amount} PKR`,
        isSimulated: true,
        status: "POSTED",
      },
    });

    await tx.ledgerEntry.createMany({
      data: [
        { transactionId: txn.id, accountId: cashAccount.id, debit: new Decimal(0), credit: amt },
        { transactionId: txn.id, accountId: principalAccount.id, debit: amt, credit: new Decimal(0) },
      ],
    });

    return txn;
  });
}

export async function getUserBalances(userId: string) {
  const cashCode = `CASH_USER_${userId}`;
  const principalCode = `PRINCIPAL_USER_${userId}`;

  const [cashAcc, principalAcc] = await Promise.all([
    prisma.ledgerAccount.findUnique({ where: { code: cashCode } }),
    prisma.ledgerAccount.findUnique({ where: { code: principalCode } }),
  ]);

  async function balanceOf(accountId: string | undefined) {
    if (!accountId) return new Decimal(0);
    const entries = await prisma.ledgerEntry.findMany({ where: { accountId } });
    let bal = new Decimal(0);
    for (const e of entries) {
      bal = bal.add(e.debit).sub(e.credit);
    }
    return bal;
  }

  const availableCash = await balanceOf(cashAcc?.id);
  const investedPrincipal = await balanceOf(principalAcc?.id);

  return {
    availableCash: availableCash.toNumber(),
    investedPrincipal: investedPrincipal.toNumber(),
    totalPortfolio: availableCash.add(investedPrincipal).toNumber(),
  };
}
