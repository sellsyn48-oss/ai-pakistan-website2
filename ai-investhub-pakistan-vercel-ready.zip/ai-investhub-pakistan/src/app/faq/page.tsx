export default function Page() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-navy-900">Faq</h1>
      <div className="mt-6 prose prose-slate text-slate-700">
        <p>
          This is a placeholder page for <strong>Faq</strong> in the AI InvestHub Pakistan MVP.
        </p>
        <p className="mt-4 text-sm text-amber-700">
          DEMO MODE — Content will be expanded with full legal, risk, and operational text before any production launch.
        </p>
        <p className="mt-4">
          All investment-related statements on this platform are for demonstration purposes only.
          No real funds are accepted or managed until regulatory and operational requirements are met.
        </p>
      </div>
    </div>
  );
}
