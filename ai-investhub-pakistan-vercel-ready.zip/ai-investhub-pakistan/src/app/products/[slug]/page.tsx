import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { getSession } from "@/lib/auth/session";
import { formatPKR } from "@/lib/utils/format";
import { InvestForm } from "@/components/products/InvestForm";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await prisma.investmentProduct.findUnique({
    where: { slug },
  });
  if (!product || product.status !== "ACTIVE") notFound();

  const session = await getSession();

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <Link href="/products" className="text-sm text-emerald-600 hover:underline">
        ← Back to products
      </Link>
      <div className="mt-4 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-navy-900">{product.name}</h1>
          <p className="mt-1 text-slate-600">{product.issuer}</p>
        </div>
        <span className="badge-demo">DEMO PRODUCT</span>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <h2 className="font-semibold">Description</h2>
            <p className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">
              {product.description}
            </p>
          </div>
          <div className="card">
            <h2 className="font-semibold">Key terms</h2>
            <dl className="mt-3 grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-slate-500">Minimum investment</dt>
                <dd className="font-medium">{formatPKR(product.minInvestment.toString())}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Maximum</dt>
                <dd className="font-medium">
                  {product.maxInvestment
                    ? formatPKR(product.maxInvestment.toString())
                    : "—"}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Duration</dt>
                <dd className="font-medium">
                  {product.durationMonths ? `${product.durationMonths} months` : "Open-ended"}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Risk class</dt>
                <dd className="font-medium">{product.riskClass}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Liquidity</dt>
                <dd className="font-medium">{product.liquidity || "—"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Currency</dt>
                <dd className="font-medium">{product.currency}</dd>
              </div>
            </dl>
          </div>
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
            All figures and terms on this page are for demonstration only. No real
            investment is executed. Read the full risk disclosure before any real
            investment activity.
          </div>
        </div>

        <div>
          <div className="card sticky top-24">
            <h2 className="font-semibold">Invest (Simulated)</h2>
            <p className="mt-1 text-xs text-slate-500">
              Uses your demo cash balance. No real money moves.
            </p>
            {session ? (
              <InvestForm
                productId={product.id}
                minInvestment={Number(product.minInvestment)}
                maxInvestment={product.maxInvestment ? Number(product.maxInvestment) : undefined}
              />
            ) : (
              <div className="mt-4">
                <p className="text-sm text-slate-600">Log in to place a simulated order.</p>
                <Link href="/login" className="btn-primary mt-3 block text-center text-sm">
                  Log in
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
