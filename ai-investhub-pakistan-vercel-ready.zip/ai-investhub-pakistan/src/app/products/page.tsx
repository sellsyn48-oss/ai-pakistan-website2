import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { formatPKR } from "@/lib/utils/format";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  const products = await prisma.investmentProduct.findMany({
    where: { status: "ACTIVE" },
    orderBy: { name: "asc" },
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-navy-900">Investment Products</h1>
          <p className="mt-2 text-slate-600">
            All products shown are DEMO products with simulated data.
          </p>
        </div>
        <span className="badge-demo">DEMO ONLY</span>
      </div>

      {products.length === 0 ? (
        <p className="mt-8 text-slate-500">No active products. Run the seed script.</p>
      ) : (
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {products.map((p) => (
            <div key={p.id} className="card flex flex-col">
              <div className="flex items-start justify-between">
                <h2 className="text-xl font-semibold text-navy-900">{p.name}</h2>
                <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium">
                  {p.riskClass}
                </span>
              </div>
              <p className="mt-2 flex-1 text-sm text-slate-600">{p.shortDescription}</p>
              <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-slate-500">Min investment</span>
                  <p className="font-medium">{formatPKR(p.minInvestment.toString())}</p>
                </div>
                <div>
                  <span className="text-slate-500">Duration</span>
                  <p className="font-medium">{p.durationMonths ? `${p.durationMonths} months` : "Open"}</p>
                </div>
                <div>
                  <span className="text-slate-500">Issuer</span>
                  <p className="font-medium">{p.issuer}</p>
                </div>
                <div>
                  <span className="text-slate-500">Category</span>
                  <p className="font-medium">{p.category}</p>
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <Link
                  href={`/products/${p.slug}`}
                  className="btn-primary flex-1 text-center text-sm"
                >
                  View details
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-12 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        <strong>Important:</strong> These are demonstration products only. They do not
        represent real investment opportunities. No real capital is accepted or invested
        through this MVP. Always read product terms, fees, and risk disclosures before
        making any real investment decision with authorized providers.
      </div>
    </div>
  );
}
