import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { getSession } from "@/lib/auth/session";
import { postDeposit } from "@/lib/ledger/engine";
import { Decimal } from "@prisma/client/runtime/library";

const schema = z.object({
  amount: z.number().positive().max(10000000),
});

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { amount } = schema.parse(await req.json());

    const deposit = await prisma.depositRequest.create({
      data: {
        userId: session.user.id,
        amount: new Decimal(amount),
        status: "CONFIRMED",
        isSimulated: true,
        confirmedAt: new Date(),
      },
    });

    await postDeposit(session.user.id, amount, deposit.id);

    return NextResponse.json({ ok: true, depositId: deposit.id });
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }
    console.error(e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
