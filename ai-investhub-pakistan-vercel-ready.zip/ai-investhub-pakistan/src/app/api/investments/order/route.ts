import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { getSession } from "@/lib/auth/session";
import { postInvestment } from "@/lib/ledger/engine";
import { Decimal } from "@prisma/client/runtime/library";

const schema = z.object({
  productId: z.string().min(1),
  amount: z.number().positive(),
});

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { productId, amount } = schema.parse(body);

    const product = await prisma.investmentProduct.findUnique({ where: { id: productId } });
    if (!product || product.status !== "ACTIVE") {
      return NextResponse.json({ error: "Product not available" }, { status: 400 });
    }

    if (amount < Number(product.minInvestment)) {
      return NextResponse.json({ error: "Below minimum investment" }, { status: 400 });
    }
    if (product.maxInvestment && amount > Number(product.maxInvestment)) {
      return NextResponse.json({ error: "Above maximum investment" }, { status: 400 });
    }

    // Create order
    const order = await prisma.investmentOrder.create({
      data: {
        userId: session.user.id,
        productId,
        amount: new Decimal(amount),
        status: "SUBMITTED",
        isSimulated: true,
      },
    });

    // Attempt ledger post (will throw if insufficient cash)
    try {
      await postInvestment(session.user.id, amount, order.id);
    } catch (err: unknown) {
      await prisma.investmentOrder.update({
        where: { id: order.id },
        data: { status: "REJECTED", rejectedReason: (err as Error).message },
      });
      return NextResponse.json(
        { error: (err as Error).message || "Insufficient funds" },
        { status: 400 }
      );
    }

    // Mark executed and create holding
    await prisma.investmentOrder.update({
      where: { id: order.id },
      data: { status: "EXECUTED", executedAt: new Date() },
    });

    await prisma.investmentHolding.create({
      data: {
        userId: session.user.id,
        productId,
        orderId: order.id,
        units: new Decimal(amount), // 1:1 for demo
        costBasis: new Decimal(amount),
        currentValue: new Decimal(amount),
        investedAt: new Date(),
        status: "ACTIVE",
      },
    });

    return NextResponse.json({ ok: true, orderId: order.id });
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error(e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
