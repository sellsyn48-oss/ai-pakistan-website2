"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function DepositPage() {
  const router = useRouter();
  const [amount, setAmount] = useState(50000);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg("");
    try {
      const res = await fetch("/api/deposits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMsg(data.error || "Failed");
        return;
      }
      setMsg("Simulated deposit confirmed. Balance updated.");
      setTimeout(() => router.push("/dashboard"), 1500);
    } catch {
      setMsg("Network error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <Link href="/dashboard" className="text-sm text-emerald-600">← Dashboard</Link>
      <div className="card mt-4">
        <h1 className="text-xl font-bold">Simulate Deposit</h1>
        <p className="mt-1 text-sm text-slate-600">
          Credits your demo cash balance. No real payment is processed.
        </p>
        <span className="badge-demo mt-2">DEMO</span>
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium">Amount (PKR)</label>
            <input
              type="number"
              className="input mt-1"
              value={amount}
              min={1000}
              step={1000}
              onChange={(e) => setAmount(Number(e.target.value))}
              required
            />
          </div>
          {msg && <p className="text-sm text-emerald-600">{msg}</p>}
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Processing..." : "Confirm simulated deposit"}
          </button>
        </form>
      </div>
    </div>
  );
}
