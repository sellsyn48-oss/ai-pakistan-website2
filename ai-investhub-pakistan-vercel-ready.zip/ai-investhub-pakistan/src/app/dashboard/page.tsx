import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { getUserBalances } from "@/lib/ledger/engine";
import { prisma } from "@/lib/db/prisma";
import { formatPKR, formatDate } from "@/lib/utils/format";
import Link from "next/link";
import { Wallet, TrendingUp, ArrowDownCircle, ArrowUpCircle, LogOut } from "lucide-react";

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const { user } = session;
  const balances = await getUserBalances(user.id);

  const holdings = await prisma.investmentHolding.findMany({
    where: { userId: user.id, status: "ACTIVE" },
    include: { product: true },
    orderBy: { investedAt: "desc" },
  });

  const recentDeposits = await prisma.depositRequest.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  const recentOrders = await prisma.investmentOrder.findMany({
    where: { userId: user.id },
    include: { product: true },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">
            Welcome{user.profile?.fullLegalName ? `, ${user.profile.fullLegalName}` : ""}
          </h1>
          <p className="text-sm text-slate-600">
            {user.email} · Role: {user.role}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="badge-demo">DEMO MODE — Simulated balances</span>
          <form action="/api/auth/logout" method="POST">
            <button
              formAction={async () => {
                "use server";
                const { destroySession } = await import("@/lib/auth/session");
                await destroySession();
                redirect("/login");
              }}
              className="btn-secondary text-sm"
            >
              <LogOut className="mr-1 h-4 w-4" />
              Log out
            </button>
          </form>
        </div>
      </div>

      {/* Balance cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Wallet className="h-4 w-4" /> Available Cash
          </div>
          <p className="mt-2 text-2xl font-bold text-navy-900">
            {formatPKR(balances.availableCash)}
          </p>
          <p className="text-xs text-amber-600">Simulated</p>
        </div>
        <div className="card">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <TrendingUp className="h-4 w-4" /> Invested Principal
          </div>
          <p className="mt-2 text-2xl font-bold text-navy-900">
            {formatPKR(balances.investedPrincipal)}
          </p>
          <p className="text-xs text-amber-600">Simulated</p>
        </div>
        <div className="card">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            Portfolio Value
          </div>
          <p className="mt-2 text-2xl font-bold text-emerald-600">
            {formatPKR(balances.totalPortfolio)}
          </p>
          <p className="text-xs text-amber-600">Demo total</p>
        </div>
        <div className="card">
          <div className="text-sm text-slate-500">Verification</div>
          <p className="mt-2 text-lg font-semibold">
            {user.verification?.status || "NOT_STARTED"}
          </p>
        </div>
      </div>

      {/* Quick actions */}
      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/products" className="btn-primary text-sm">
          Browse Products
        </Link>
        <Link href="/dashboard/deposit" className="btn-secondary text-sm">
          <ArrowDownCircle className="mr-1 h-4 w-4" /> Simulate Deposit
        </Link>
        <Link href="/dashboard/withdraw" className="btn-secondary text-sm">
          <ArrowUpCircle className="mr-1 h-4 w-4" /> Request Withdrawal
        </Link>
        {(user.role === "SUPER_ADMIN" || user.role === "ADMIN") && (
          <Link href="/admin" className="btn-secondary text-sm">
            Admin Panel
          </Link>
        )}
      </div>

      {/* Holdings */}
      <div className="mt-10">
        <h2 className="text-lg font-semibold text-navy-900">Active Holdings</h2>
        {holdings.length === 0 ? (
          <p className="mt-3 text-sm text-slate-600">
            No holdings yet.{" "}
            <Link href="/products" className="text-emerald-600 underline">
              Explore products
            </Link>
          </p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b text-left text-slate-500">
                  <th className="py-2 pr-4">Product</th>
                  <th className="py-2 pr-4">Cost Basis</th>
                  <th className="py-2 pr-4">Current Value</th>
                  <th className="py-2 pr-4">Invested</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {holdings.map((h) => (
                  <tr key={h.id} className="border-b border-slate-100">
                    <td className="py-3 pr-4 font-medium">{h.product.name}</td>
                    <td className="py-3 pr-4">{formatPKR(h.costBasis.toString())}</td>
                    <td className="py-3 pr-4">{formatPKR(h.currentValue.toString())}</td>
                    <td className="py-3 pr-4">{formatDate(h.investedAt)}</td>
                    <td className="py-3">
                      <span className="badge-demo">{h.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Recent activity */}
      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="text-lg font-semibold">Recent Orders</h2>
          {recentOrders.length === 0 ? (
            <p className="mt-2 text-sm text-slate-500">No orders yet</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {recentOrders.map((o) => (
                <li key={o.id} className="flex justify-between rounded-lg border p-3 text-sm">
                  <span>{o.product.name}</span>
                  <span>
                    {formatPKR(o.amount.toString())} · {o.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div>
          <h2 className="text-lg font-semibold">Recent Deposits</h2>
          {recentDeposits.length === 0 ? (
            <p className="mt-2 text-sm text-slate-500">No deposits yet</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {recentDeposits.map((d) => (
                <li key={d.id} className="flex justify-between rounded-lg border p-3 text-sm">
                  <span>{formatPKR(d.amount.toString())}</span>
                  <span>{d.status} · {formatDate(d.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
