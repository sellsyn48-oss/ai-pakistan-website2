import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import Link from "next/link";

export default async function AdminPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  const adminRoles = ["SUPER_ADMIN", "ADMIN", "COMPLIANCE", "FINANCE"];
  if (!adminRoles.includes(session.user.role)) {
    redirect("/dashboard");
  }

  const [userCount, productCount, orderCount, pendingWithdrawals] = await Promise.all([
    prisma.user.count(),
    prisma.investmentProduct.count(),
    prisma.investmentOrder.count(),
    prisma.withdrawalRequest.count({ where: { status: { in: ["REQUESTED", "UNDER_REVIEW"] } } }),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <span className="badge-demo">DEMO</span>
      </div>
      <p className="mt-1 text-sm text-slate-600">
        Signed in as {session.user.email} ({session.user.role})
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card">
          <p className="text-sm text-slate-500">Users</p>
          <p className="text-2xl font-bold">{userCount}</p>
        </div>
        <div className="card">
          <p className="text-sm text-slate-500">Products</p>
          <p className="text-2xl font-bold">{productCount}</p>
        </div>
        <div className="card">
          <p className="text-sm text-slate-500">Orders</p>
          <p className="text-2xl font-bold">{orderCount}</p>
        </div>
        <div className="card">
          <p className="text-sm text-slate-500">Pending withdrawals</p>
          <p className="text-2xl font-bold">{pendingWithdrawals}</p>
        </div>
      </div>

      <div className="mt-10">
        <h2 className="font-semibold">Modules (MVP skeleton)</h2>
        <ul className="mt-3 space-y-2 text-sm text-slate-700">
          <li>• User management — extend with list/search/roles</li>
          <li>• Product management — create/edit/activate products</li>
          <li>• Order & transaction monitoring</li>
          <li>• Deposit / withdrawal review</li>
          <li>• Audit log viewer</li>
          <li>• System settings & feature flags</li>
        </ul>
        <p className="mt-4 text-sm text-slate-500">
          Full admin modules are outlined in the schema and can be expanded in later phases.
        </p>
        <Link href="/dashboard" className="btn-secondary mt-6 inline-flex text-sm">
          Back to investor dashboard
        </Link>
      </div>
    </div>
  );
}
