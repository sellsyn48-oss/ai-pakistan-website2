import Link from "next/link";
import {
  Shield,
  TrendingUp,
  Brain,
  Lock,
  FileText,
  BarChart3,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-900 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-emerald-500/10 via-transparent to-transparent" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="max-w-3xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-amber-500/20 px-3 py-1 text-xs font-medium text-amber-300">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
              DEMO MODE — Simulated funds only. No real money is processed.
            </div>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
              Smarter Investment Management,{" "}
              <span className="text-emerald-400">Powered by AI</span>
            </h1>
            <p className="mt-6 text-lg text-slate-300">
              AI InvestHub Pakistan helps you explore investment products, manage your
              portfolio, and understand your financial position with transparent
              accounting and AI-assisted insights — designed for the Pakistani market.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/register" className="btn-primary">
                Create Account
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
              <Link href="/products" className="btn-secondary border-slate-600 bg-transparent text-white hover:bg-white/10">
                View Products
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust / What we do */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-navy-900">Built for transparency</h2>
          <p className="mt-3 text-slate-600 max-w-2xl mx-auto">
            We focus on clear accounting, documented product terms, and honest
            disclosures. This platform is currently in demonstration mode.
          </p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Shield,
              title: "Secure Accounts",
              desc: "Hashed credentials, session controls, and role-based access.",
            },
            {
              icon: FileText,
              title: "Transparent Ledger",
              desc: "Double-entry style records for deposits, investments, and fees.",
            },
            {
              icon: Brain,
              title: "AI Assistant",
              desc: "Explain your portfolio, fees, and risks in plain language.",
            },
            {
              icon: Lock,
              title: "Compliance Ready",
              desc: "Designed with KYC, audit logs, and regulatory gates in mind.",
            },
          ].map((item) => (
            <div key={item.title} className="card">
              <item.icon className="h-8 w-8 text-emerald-500" />
              <h3 className="mt-4 font-semibold text-navy-900">{item.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-navy-900">How it works</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-4">
            {[
              { step: "1", title: "Register & Verify", desc: "Create an account and complete identity checks when required." },
              { step: "2", title: "Explore Products", desc: "Review terms, fees, risks, and eligibility for each product." },
              { step: "3", title: "Invest (Simulated)", desc: "Place orders using demo balances. Real money stays disabled." },
              { step: "4", title: "Track & Learn", desc: "View holdings, statements, and AI explanations of your portfolio." },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-lg font-bold text-emerald-700">
                  {s.step}
                </div>
                <h3 className="mt-4 font-semibold text-navy-900">{s.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Risk notice */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-6">
          <h3 className="font-semibold text-amber-900">Important risk & regulatory notice</h3>
          <ul className="mt-3 space-y-2 text-sm text-amber-800">
            <li className="flex gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
              Investments involve risk of loss. Past performance is not indicative of future results.
            </li>
            <li className="flex gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
              This software demonstration does not hold a SECP license and does not offer real investment products.
            </li>
            <li className="flex gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
              No fixed or guaranteed returns are promised. All figures shown in DEMO mode are simulated.
            </li>
            <li className="flex gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
              Real-money functionality will only be enabled after required legal, regulatory, and provider approvals.
            </li>
          </ul>
          <Link href="/risk-disclosure" className="mt-4 inline-block text-sm font-medium text-amber-900 underline">
            Read full risk disclosure →
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy-900 py-16 text-center text-white">
        <h2 className="text-3xl font-bold">Ready to explore the platform?</h2>
        <p className="mt-3 text-slate-300">
          Create a free demo account and experience the investor dashboard with simulated funds.
        </p>
        <Link href="/register" className="btn-primary mt-8 inline-flex">
          Start Demo Account
        </Link>
      </section>
    </div>
  );
}
