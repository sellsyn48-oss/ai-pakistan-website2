import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-navy-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <h3 className="text-lg font-bold text-white">AI InvestHub Pakistan</h3>
            <p className="mt-2 text-sm">
              Smarter Investment Management, Powered by AI.
            </p>
            <p className="mt-4 text-xs text-amber-400">
              DEMO / SIMULATED MODE — No real money is processed.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-white">Platform</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link href="/products" className="hover:text-white">Investment Products</Link></li>
              <li><Link href="/how-it-works" className="hover:text-white">How It Works</Link></li>
              <li><Link href="/pricing" className="hover:text-white">Fees & Pricing</Link></li>
              <li><Link href="/risk-disclosure" className="hover:text-white">Risk Disclosure</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white">Legal</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link href="/terms" className="hover:text-white">Terms & Conditions</Link></li>
              <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
              <li><Link href="/risk-disclosure" className="hover:text-white">Risk Disclosure</Link></li>
              <li><Link href="/faq" className="hover:text-white">FAQ</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white">Support</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
              <li><Link href="/help" className="hover:text-white">Help Center</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 border-t border-navy-800 pt-6 text-center text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} AI InvestHub Pakistan. All rights reserved.
          </p>
          <p className="mt-1">
            This is a software demonstration. It does not constitute an offer to invest,
            investment advice, or a collective investment scheme. Real-money features
            remain disabled until all applicable regulatory and operational requirements
            are satisfied.
          </p>
        </div>
      </div>
    </footer>
  );
}
