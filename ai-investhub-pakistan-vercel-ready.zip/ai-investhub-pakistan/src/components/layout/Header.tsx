"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, Shield } from "lucide-react";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-900">
            <Shield className="h-5 w-5 text-emerald-500" />
          </div>
          <div>
            <span className="text-lg font-bold text-navy-900">AI InvestHub</span>
            <span className="ml-1 text-sm font-medium text-emerald-500">Pakistan</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/products" className="text-sm font-medium text-slate-600 hover:text-navy-900">
            Investments
          </Link>
          <Link href="/how-it-works" className="text-sm font-medium text-slate-600 hover:text-navy-900">
            How It Works
          </Link>
          <Link href="/pricing" className="text-sm font-medium text-slate-600 hover:text-navy-900">
            Fees
          </Link>
          <Link href="/risk-disclosure" className="text-sm font-medium text-slate-600 hover:text-navy-900">
            Risks
          </Link>
          <Link href="/faq" className="text-sm font-medium text-slate-600 hover:text-navy-900">
            FAQ
          </Link>
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Link href="/login" className="btn-secondary text-sm">
            Log in
          </Link>
          <Link href="/register" className="btn-primary text-sm">
            Get Started
          </Link>
        </div>

        <button
          className="md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white px-4 py-4 md:hidden">
          <div className="flex flex-col gap-3">
            <Link href="/products" onClick={() => setOpen(false)}>Investments</Link>
            <Link href="/how-it-works" onClick={() => setOpen(false)}>How It Works</Link>
            <Link href="/pricing" onClick={() => setOpen(false)}>Fees</Link>
            <Link href="/risk-disclosure" onClick={() => setOpen(false)}>Risks</Link>
            <Link href="/faq" onClick={() => setOpen(false)}>FAQ</Link>
            <div className="flex gap-2 pt-2">
              <Link href="/login" className="btn-secondary flex-1 text-center text-sm">Log in</Link>
              <Link href="/register" className="btn-primary flex-1 text-center text-sm">Get Started</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
