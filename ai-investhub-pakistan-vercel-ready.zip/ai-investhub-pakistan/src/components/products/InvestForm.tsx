"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function InvestForm({
  productId,
  minInvestment,
  maxInvestment,
}: {
  productId: string;
  minInvestment: number;
  maxInvestment?: number;
}) {
  const router = useRouter();
  const [amount, setAmount] = useState(minInvestment);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    try {
      const res = await fetch("/api/investments/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, amount }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ type: "err", text: data.error || "Order failed" });
        return;
      }
      setMessage({ type: "ok", text: "Simulated investment executed successfully." });
      router.refresh();
    } catch {
      setMessage({ type: "err", text: "Network error" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4 space-y-4">
      <div>
        <label className="block text-sm font-medium">Amount (PKR)</label>
        <input
          type="number"
          className="input mt-1"
          value={amount}
          min={minInvestment}
          max={maxInvestment}
          step={1000}
          onChange={(e) => setAmount(Number(e.target.value))}
          required
        />
        <p className="mt-1 text-xs text-slate-500">
          Min {minInvestment.toLocaleString()} PKR
          {maxInvestment ? ` · Max ${maxInvestment.toLocaleString()} PKR` : ""}
        </p>
      </div>
      {message && (
        <p className={`text-sm ${message.type === "ok" ? "text-emerald-600" : "text-red-600"}`}>
          {message.text}
        </p>
      )}
      <button type="submit" className="btn-primary w-full text-sm" disabled={loading}>
        {loading ? "Processing..." : "Confirm simulated investment"}
      </button>
    </form>
  );
}
